/*                                                                                                                                                   
 * Filename program5.cc
 * Date November 17, 2020                                                                                                                            
 * Author Zainab Anwar                                                                                                                               
 * Email zxa180005@utdallas.edu                                                                                                                      
 * Course CS 3377.002 Fall 2020                                                                                                                      
 * Version 1.0                                                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This file is the main file and includes all the TCLAP information,
 * and also contains the code for the daemon as well as forking, 
 * also determines if the daemon was used or not. 
 */

#include "header.h"

using namespace std;

ofstream log;
map <string, string> optionMap;
bool VERBOSE = false;

int main(int argc, char*argv[])
{

  try
    {
      TCLAP::CmdLine cmd("cs3377dirmond Directory Monitor Daemon", ' ', "1.0"); //Command Line Arguments                                                        
      TCLAP::SwitchArg daemonFlag("d","daemon","Run in daemon mode (forks to run as a daemon).", cmd, false);
      TCLAP::UnlabeledValueArg<std::string> configArg("configfilename", "The name of the configuration file. Defaults to cs3377dirmond.conf", false, "cs3377dirmond.conf", "config filename", false);
      cmd.add(configArg);
      cmd.parse(argc, argv);

      //enum Options {daemon, configFile}; //Map                                                                                      

      optionMap["configFile"] = configArg.getValue();
      /*
      signal(SIGINT, signalHandling);
      signal(SIGTERM, signalHandling);
      signal(SIGHUP, signalHandling);
      */
      if(parseConfigFile())     
	{
	  mkdir("/home/012/z/zx/zxa180005/testdir/.versions/", 0755);

	  if(daemonFlag.getValue() == true)
	    {
	      pid_t forkValue;
	      forkValue = fork();

	      if(forkValue == -1)
		{
		  cerr << "There was an error in the fork. No child was created." << endl;
		  exit(EXIT_FAILURE);
		}
	      if(forkValue == 0)
		{
                  startLogging();
		  while(1)
		    {
		    }		 
		  cout << "Child Exiting" << endl;
		  exit(EXIT_SUCCESS);
		}
	      else
		{
		  cout << "Running as daemon. My child's pid is: " << forkValue << endl;
		}
	    }
	  else
	    {
	      cout << "Program not running as daemon." << endl;
	      startLogging();	    
	      while(1)
		{
		}
	    }
	}        
      return 0;
    }
  catch (TCLAP::ArgException &e)
    {
      cerr << "ERROR: " << e.error() << " for arg " << e.argId() << endl;
    }

  return 0;
}
