/*                                                                                                                                                   
 * Filename processControl.cc
 * Date November 17, 2020                                                                                                                            
 * Author Zainab Anwar                                                                                                                               
 * Email zxa180005@utdallas.edu                                                                                                                      
 * Course CS 3377.002 Fall 2020                                                                                                                      
 * Version 1.0                                                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This file creates a pid file with the pid id,
 * and also logs the inotify functions.
 */

#include "header.h"

using namespace std;

extern ofstream log;
extern map <string, string> optionMap;
/*
const int BUFFER_SIZE3 = 1024;
char versionsOutput[BUFFER_SIZE3];
FILE *makeVersions = popen("mkdir (/home/012/z/zx/zxa180005/testdir/.versions", "w");
*/

void startLogging()
{
  log.open(optionMap["LogFile"].c_str(), ios::app);
   inotifyFunctions();

  ofstream pidFile;

  struct stat sb;
  if(stat("cs3377dirmond.pid", &sb))
    {
      pidFile.open("cs3377dirmond.pid");
      if(!pidFile)
        {
          cerr << "Error! Cannot create or open pid file" << endl;
          exit(0);
        }
      log << "creating pid file" << endl;
      pidFile << getpid() << endl;
      //      inotifyFunctions();

      signal(SIGINT, signalHandling);
      signal(SIGTERM, signalHandling);
      signal(SIGHUP, signalHandling);


      pidFile.close();
    }
  else
    {
      log << "pid file already exists" << endl;
      exit(0);
    }
  /* if(makeVersions)
    {
      fgets(versionsOutput, BUFFER_SIZE3, makeVersions);
    }
  pclose(makeVersions);
  printf("%s", versionsOutput);
  */
}
