/*                                                                                                                                                   
 * Filename signalHandling.cc
 * Date November 17, 2020                                                                                                                            
 * Author Zainab Anwar                                                                                                                               
 * Email zxa180005@utdallas.edu                                                                                                                      
 * Course CS 3377.002 Fall 2020                                                                                                                      
 * Version 1.0                                                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This file deals with all the signals to stop processes,
 * it also prints out the signal and what was used.
 */

#include "header.h"

using namespace std;

extern ofstream log;

void signalHandling(int num)
{
  log.open("cs3377dirmond.log", ios::app); //remove                                                                                      

  cout << " Interrupt signal (" << num << ") received.\n";
  if(num == SIGINT || num == SIGTERM)
    {
      remove("cs3377dirmond.pid"); // ./cs3377dirmond.pid

      log << "Exiting Program" << endl;

      log.close();
      exit(num);
    }
  else if(num == SIGHUP)
    {
      rereadConfigFile();
    }
}
