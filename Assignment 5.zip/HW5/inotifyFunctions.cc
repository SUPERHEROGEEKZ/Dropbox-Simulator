/* 
 * Filename     inotifyFunctions.cc                                                                                                                 
 * Date         November 17, 2020
 * Author       Zainab Anwar                                                                                                                         
 * Email        zxa180005@utdallas.edu                                                                                                               
 * Course       CS 3377.002 Fall 2020                                                                                                                
 * Version      1.0                                                                                                                                  
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This file implements inotify to send "notifications" that a file is modified
 * while also creates a copy of the modified file in .versions and gives it a date.
 *                                                                                                                                                   
 */

#include "header.h"

using namespace std;

#define EVENT_SIZE  (sizeof(struct inotify_event))
#define BUF_LEN     (1024*(EVENT_SIZE + 16))

extern map <string, string> optionMap;
extern ofstream log;

void inotifyFunctions()
{
  // int length, i = 0;
  int fd;
  int wd;
  // char buffer[BUF_LEN];


  const int BUFFER_SIZE = 1024;
  char output[BUFFER_SIZE];
  FILE *command = popen("date +.%Y.%m.%d-%H:%M:%S", "r");
  /*
  const int BUFFER_SIZE2 = 1024;
  char makeCopy[BUFFER_SIZE2];
  FILE *copyCommand = popen("cp date +.%Y.%m.%d-%H:%M:%S", "w");
  */

  fd = inotify_init();

  if (fd < 0) 
    {
      perror("inotify_init");
    }

  wd = inotify_add_watch(fd, optionMap["WatchDir"].c_str(), IN_MODIFY);
  if (wd < 0)
    {
      perror("inotify_add_watch");
    }
  
  while(1)
    {
      //      log.open(optionMap["LogFile"].c_str(), ios::app);//
      int length, i = 0;
      char buffer[BUF_LEN];    
      
      length = read(fd, buffer, BUF_LEN);  
      if (length < 0) 
	{
	  perror("read");
	}
      while (i < length) 
	{
	  struct inotify_event *event = (struct inotify_event *) &buffer[i];
	  if (event->len) 
	    {
	      if (event->mask & IN_MODIFY)
		{
		  if (event->mask & IN_ISDIR)
		    {
		      log << "This directory was modified: " << event->name << endl;       
		    }
		  else 
		    {
                      log << "This file was modified: " << event->name << endl;		     

		      string modifiedFileName = event->name;
		      string fileToCopy = optionMap["WatchDir"] + "/" + modifiedFileName;
		      string pathToVersions = optionMap["WatchDir"] + "/.versions/";
		      
		      string fileAdded = pathToVersions + modifiedFileName + fgets(output, BUFFER_SIZE, command);
		      
		      string copyFile = "cp " + fileToCopy + " " + fileAdded;
		      FILE *versions = popen(copyFile.c_str(), "w");
		      fprintf(versions, copyFile.c_str());
		      pclose(versions);
		      
		      /* if(command)
			 {
			 fgets(output, BUFFER_SIZE, command);
			 }
			 pclose(command);
			 printf("%s", output);
		      
			 if(copyCommand)
			 {
			 fgets(makeCopy, BUFFER_SIZE2, copyCommand);
			 }
			 pclose(copyCommand);
			 printf("%s", makeCopy);
		      */
		    
		    }
		}
	    }
	  i += EVENT_SIZE + event->len;
	}
    }
  (void) inotify_rm_watch(fd, wd);
  (void) close(fd);
}
