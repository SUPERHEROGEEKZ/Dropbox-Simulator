/*                                                                                                                                                   
 * Filename parseConfigFile.cc
 * Date November 17, 2020                                                                                                                            
 * Author Zainab Anwar                                                                                                                               
 * Email zxa180005@utdallas.edu                                                                                                                      
 * Course CS 3377.002 Fall 2020                                                                                                                      
 * Version 1.0                                                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This file parses the conf file by definitions, and 
 * also rereads the conf file to see if there are changes,
 * if there are then it reconfigures itself with those changes.
 */

#include "header.h"

using namespace std;
using namespace rude;

std::string Verbose = "Verbose";
std::string LogFile = "LogFile";
std::string Password = "Password";
std::string NumVersions = "NumVersions";
std::string WatchDir = "WatchDir";

extern bool VERBOSE;
extern map <string, string> optionMap;
extern ofstream log;

bool parseConfigFile()
{
  Config config;

  //  cout << FileName << endl;

  if(config.load(optionMap["configFile"].c_str()))
    {
      if(config.setSection("Parameters", false))
	{      
	  if(!config.exists(Verbose.c_str()))
	    {
	      cerr << "Verbose Definition Missing: " << config.getError() <<"\n";
	      exit(0);
	    }
	  if(!config.exists(LogFile.c_str()))
	    {
	      cerr << "LogFile Definition Missing: " << config.getError() <<"\n";
	      exit(0);
	    }
	  if(!config.exists(Password.c_str()))
	    {
	      cerr << "Password Definition Missing: " << config.getError() <<"\n";
	      exit(0);
	    }
	  if(!config.exists(NumVersions.c_str()))
	    {
	      cerr << "NumVersions Definition Missing: " << config.getError() <<"\n";
	      exit(0);
	    }
	  if(!config.exists(WatchDir.c_str()))
	    {
	      cerr << "WatchDir Definition Missing: " << config.getError() <<"\n";
              exit(0);
	    }
	}
      else
	{
	  cerr << "[Parameters] Section Missing: " << config.getError() << "\n";
	  exit(0);
	}
    }
   else
     {
       cerr << "Conf File Missing: " << config.getError() << "\n";
       exit(0);
     }
    
  optionMap[Verbose] = config.getStringValue(Verbose.c_str());
  if(optionMap[Verbose].compare("true") == 0)
    {
      VERBOSE = true;
    }
  else
    {
      VERBOSE = false;
    }

  optionMap[LogFile] = config.getStringValue(LogFile.c_str());
  optionMap[Password] = config.getStringValue(Password.c_str());
  optionMap[NumVersions] = config.getStringValue(NumVersions.c_str());
  optionMap[WatchDir] = config.getStringValue(WatchDir.c_str());

  // cout << optionMap[Verbose] << endl;
  // cout << optionMap[LogFile] << endl;
  // cout << optionMap[Password] << endl;
  // cout << optionMap[NumVersions] << endl;
  // cout << optionMap[WatchDir] << endl;

  return true;
}

void rereadConfigFile()
{
  Config config;

  if(config.load(optionMap["configFile"].c_str()))
    {
      if(config.setSection("Parameters", false))
        {
          if(!config.exists(Verbose.c_str()))
            {
              cerr << "Verbose Definition Missing: " << config.getError() <<"\n";
              exit(0);
            }
          if(!config.exists(LogFile.c_str()))
            {
              cerr << "LogFile Definition Missing: " << config.getError() <<"\n";
              exit(0);
            }
          if(!config.exists(Password.c_str()))
            {
              cerr << "Password Definition Missing: " << config.getError() <<"\n";
              exit(0);
            }
          if(!config.exists(NumVersions.c_str()))
            {
              cerr << "NumVersions Definition Missing: " << config.getError() <<"\n";
              exit(0);
            }
          if(!config.exists(WatchDir.c_str()))
            {
              cerr << "WatchDir Definition Missing: " << config.getError() <<"\n";
              exit(0);
            }
        }
      else
        {
          cerr << "[Parameters] Section Missing: " << config.getError() << "\n";
          exit(0);
        }
    }
  else
    {
      cerr << "Conf File Missing: " << config.getError() << "\n";
      exit(0);
    }

  if(optionMap[LogFile].compare(config.getStringValue(LogFile.c_str())) != 0)
     {
       optionMap[LogFile] = config.getStringValue(LogFile.c_str());
       log.close();
       log.clear();
       log.open(optionMap[LogFile].c_str(), ios::app);
     }

  if(optionMap[Verbose].compare(config.getStringValue(Verbose.c_str())) != 0)
	{
	  optionMap[Verbose] = config.getStringValue(Verbose.c_str());
	  if(optionMap[Verbose].compare("true")== 0)
	    {
	      VERBOSE = true;
	    }
	  else
	    {
	      VERBOSE = false;
	    }
	}

  optionMap[Password] = config.getStringValue(Password.c_str());
  optionMap[NumVersions] = config.getStringValue(NumVersions.c_str());
  optionMap[WatchDir] = config.getStringValue(WatchDir.c_str());

}
