/*                                                                                                                                                   
 * Filename header.h                                                                                                                                 
 * Date November 17, 2020                                                                                                                           
 * Author Zainab Anwar                                                                                                                               
 * Email zxa180005@utdallas.edu                                                                                                                      
 * Course CS 3377.002 Fall 2020                                                                                                                      
 * Version 1.0                                                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                                               
 *                                                                                                                                                   
 * Description                                                                                                                                       
 *                                                                                                                                                   
 * This header file contains include statements and function headers so that the functions could be used in any files needed.
 */

#ifndef _HEADER_
#define _HEADER_

#include <tclap/CmdLine.h>
#include <map>
#include <string>
#include <rude/config.h>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <csignal>
#include <sys/stat.h>

#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/inotify.h>

using namespace std;

bool parseConfigFile();
//extern std::map<std::int, std::string> optionMap;
//enum Options {daemon, configFile};
//extern map <string, string> optionMap;
void signalHandling(int num);
void startLogging();
void signalHandling(int num);
void rereadConfigFile();
void inotifyFunctions();

#endif

